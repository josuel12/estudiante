/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package estudiantes;

/**
 *
 * @author Rodrigo
 */
import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
        Estudiante[] estudiantes = new Estudiante[10];
        estudiantes[0] = new Estudiante("Juan", "Matemáticas", "Profesor A", 95.5);
        estudiantes[1] = new Estudiante("María", "Historia", "Profesor B", 85.0);
        estudiantes[2] = new Estudiante("Pedro", "Ciencias", "Profesor C", 91.3);
        estudiantes[3] = new Estudiante("Maríana", "fisica", "Profesor B", 85.0);
        estudiantes[4] = new Estudiante("Pepe", "Ciencias", "Profesor C", 91.3);
        estudiantes[5] = new Estudiante("Marlen", "mate", "Profesor B", 88.0);
        estudiantes[6] = new Estudiante("Peedo", "histria", "Profesor C", 98.3);
       
        StringBuilder listado = new StringBuilder("Listado de Estudiantes:\n");
        for (Estudiante estudiante : estudiantes) {
            if (estudiante != null) {
                listado.append("Nombre: ").append(estudiante.getNombre())
                        .append(", Curso: ").append(estudiante.getCurso())
                        .append(", Profesor: ").append(estudiante.getProfesor())
                        .append(", Calificación: ").append(estudiante.getCalificacion())
                        .append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, listado.toString());

        
        Estudiante mayorCalificacion = estudiantes[0];
        for (Estudiante estudiante : estudiantes) {
            if (estudiante != null && estudiante.getCalificacion() > mayorCalificacion.getCalificacion()) {
                mayorCalificacion = estudiante;
            }
        }
        JOptionPane.showMessageDialog(null, "Estudiante con la nota mayor: " + mayorCalificacion.getNombre());

        // Nombre del estudiante con la nota menor
        Estudiante menorCalificacion = estudiantes[0];
        for (Estudiante estudiante : estudiantes) {
            if (estudiante != null && estudiante.getCalificacion() < menorCalificacion.getCalificacion()) {
                menorCalificacion = estudiante;
            }
        }
        JOptionPane.showMessageDialog(null, "Estudiante con la nota menor: " + menorCalificacion.getNombre());

        // Promedio de calificaciones
        double sumaCalificaciones = 0;
        int cantidadEstudiantes = 0;
        for (Estudiante estudiante : estudiantes) {
            if (estudiante != null) {
                sumaCalificaciones += estudiante.getCalificacion();
                cantidadEstudiantes++;
            }
        }
        double promedio = sumaCalificaciones / cantidadEstudiantes;
        JOptionPane.showMessageDialog(null, "Promedio de calificaciones: " + promedio);

        // Calificaciones por encima del promedio
        StringBuilder calificacionesEncimaPromedio = new StringBuilder("Calificaciones por encima del promedio:\n");
        for (Estudiante estudiante : estudiantes) {
            if (estudiante != null && estudiante.getCalificacion() > promedio) {
                calificacionesEncimaPromedio.append(estudiante.getNombre())
                        .append(": ").append(estudiante.getCalificacion())
                        .append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, calificacionesEncimaPromedio.toString());

        // Calificaciones por debajo del promedio
        StringBuilder calificacionesDebajoPromedio = new StringBuilder("Calificaciones por debajo del promedio:\n");
        for (Estudiante estudiante : estudiantes) {
            if (estudiante != null && estudiante.getCalificacion() < promedio) {
                calificacionesDebajoPromedio.append(estudiante.getNombre())
                        .append(": ").append(estudiante.getCalificacion())
                        .append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, calificacionesDebajoPromedio.toString());
    }
}